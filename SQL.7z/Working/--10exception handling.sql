create table tbl4_ksrk005
(
	[student id] int primary key  not null,
	[first naem] nvarchar(200) not null,
	[last name] nvarchar(200) null,
	[email] nvarchar (100) null
);
insert into tbl4_ksrk005 values(1,'siva','k','ksrk005')
insert into tbl4_ksrk005 values(2,'siva2','k2','2ksrk005')
insert into tbl4_ksrk005 values(3,'siva3','k3','3ksrk005')
insert into tbl4_ksrk005 values(4,'siva4','k4','4ksrk005')
insert into tbl4_ksrk005 values(5,'siva5','k5','5ksrk005')


select * from tbl4_ksrk005

--normal exception handling
insert into tbl4_ksrk005 values(4,'siva2','k2','2ksrk005')


declare @errorcode int
set @errorcode = @@ERROR

if @errorcode>0
begin
	print 'error' 
	print @errorcode
end

--default try catch exception handling



declare @errorcode2 int
set @errorcode2 = @@ERROR

begin try
	insert into tbl4_ksrk005 values(4,'siva2','k2','2ksrk005')
end try
begin catch
	print 'error' 
	print error_number()
end catch



--throw 

BEGIN TRY

 DECLARE @result INT

--Generate casting error

 SET @result = 'This is test'

END TRY

BEGIN CATCH

 THROW

END CATCH


--raise error

BEGIN TRY
DECLARE @result2 INT
--Generate casting error
  SET @result2= 'This is test'
END TRY
BEGIN CATCH
 DECLARE @Error2Message NVARCHAR(2048),
         @Error2Severity INT,
         @Error2State INT
 SELECT
   @Error2Message =ERROR_MESSAGE(),
   @Error2Severity =ERROR_SEVERITY(),
   @Error2State =ERROR_STATE()
  
 RAISERROR (@Error2Message, @Error2Severity,@Error2State)
END CATCH 

