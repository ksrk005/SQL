CREATE TABLE tblEmployee2_siva (
    E_ID int primary key,
	E_First_Name varchar(23),
	E_Last_Name varchar(23),
);

/*insert into table two types*/
/*type 1*/
insert into tblEmployee2_siva
values(1,'z','a')
insert into tblEmployee2_siva
values(2,'y','b')
insert into tblEmployee2_siva
values(3,'x','c')
insert into tblEmployee2_siva
values(4,'w','d')
/*type 2*/
insert into tblEmployee2_siva(E_ID,E_First_Name) 
values (5,'v')


create proc movecolumn
   (@C1 int)
AS
BEGIN
    INSERT INTO tblEmployee2_siva(E_First_Name) --- Columns of smaller table
        SELECT E_ID,E_First_Name,E_Last_Name,Genders,address ---Columns of Master table
        FROM tblEmployee_siva
        WHERE E_ID = @C1 --- Where value of C1 of Master table matches the value of @C1
END