--function (returns value,lighter weight oly select,qureise simplied for complex quries-execution plan,fight against sql injection)


create function ksrk1square(@v1 int)
returns int
begin
	declare @result int;
	set @result=@v1*@v1;
	return @result
end
select dbo.ksrk1square(6) as squarevalueksrk1square