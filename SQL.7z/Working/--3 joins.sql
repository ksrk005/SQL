create table c
(
cid int primary key,
cfn varchar(25),
cln varchar(25),
oid int
);
create table o
(
oid int primary key,
ona varchar(25)
);
drop table c
drop table o
select * from c
select * from o
insert into c
values (1,'a','z',11)
insert into c
values (2,'b','y',22)
insert into c
values (3,'c','x',33)
insert into c
values (4,'d','w',44)
insert into o
values (11,'aa')
insert into o
values (22,'bb')



-- inner join--
select c.cid,c.cfn,c.cln,o.oid,o.ona from c inner join o
on c.oid=o.oid
select c.cid,c.cfn,c.cln,o.oid,o.ona from c  join o
on c.oid=o.oid


--left outer join--
select c.cid,c.cfn,c.cln,o.oid,o.ona from c left join o
on c.oid=o.oid


--right outer join--
select c.cid,c.cfn,c.cln,o.oid,o.ona from c right join o
on c.oid=o.oid


----selfjoin
create table empsiva
(
empid int primary key,
name nvarchar(50),
managerid int
)
insert into empsiva
select 1,'a',3
union all
select 2,'b',3
union all
select 3,'c',null
union all
select 4,'d',2
union all
select 5,'e',2
union all
select 6,'f',2

--inner join
select e1.name as employeename ,e2.name as managername
from empsiva e1
inner join empsiva e2
on e1.managerid=e2.empid

--without inner join like two tables
select e1.name as employeename ,e2.name as managername
from empsiva e1, empsiva e2
where e1.managerid=e2.empid



----outer join
select e1.name as employeename ,e2.name as managername
from empsiva e1 full join empsiva e2
on e1.managerid=e2.empid