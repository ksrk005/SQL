-- stored procedure (doesnt return value,greater weight alter table)
-- procedure or proc(keywords)
-- create and alter

select * from tblEmployee_siva

--creating
create procedure GEN(@EID int)
as
begin
select E_First_Name+' '+E_Last_Name
from tblEmployee_siva 
where E_ID=@EID
end


exec GEN 9


--altering
alter procedure GEN(@EID int)
as
begin
select E_Last_Name +' '+ E_First_Name
from tblEmployee_siva 
where E_ID=@EID
end
exec GEN 9


--altering
alter procedure GEN(@EID int)
as
begin
select E_Last_Name +' '+ E_First_Name+' '+ Genders
from tblEmployee_siva 
where E_ID=@EID
end
exec GEN 10



--conversion code should be written (string and integer)
alter procedure GEN(@EID int)
as
begin
select E_Last_Name +' '+ E_First_Name+' '+ E_ID
from tblEmployee_siva 
where E_ID=@EID
end
exec GEN 10


--returning values
-- 23 and 25 for limit 
alter proc GEN(@EID int, @ou varchar(23) out)
as
begin
select @ou=E_Last_Name +' '+ E_First_Name
from tblEmployee_siva 
where E_ID=@EID
end
declare @outName varchar(23)
exec GEN 10,@outName output
select @outName as Nameskdhfbg
