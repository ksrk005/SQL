----index
CREATE TABLE student123siva
(
    id INT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    gender VARCHAR(50) NOT NULL,
    DOB datetime NOT NULL,
    total_score INT NOT NULL,
    city VARCHAR(50) NOT NULL
 )

 EXECUTE sp_helpindex student123siva

 INSERT INTO student123siva
 
VALUES  
(6, 'Kate', 'Female', '03-JAN-1985', 500, 'Liverpool'), 
(2, 'Jon', 'Male', '02-FEB-1974', 545, 'Manchester'),
(9, 'Wise', 'Male', '11-NOV-1987', 499, 'Manchester'), 
(3, 'Sara', 'Female', '07-MAR-1988', 600, 'Leeds'), 
(1, 'Jolly', 'Female', '12-JUN-1989', 500, 'London'),
(4, 'Laura', 'Female', '22-DEC-1981', 400, 'Liverpool'),
(7, 'Joseph', 'Male', '09-APR-1982', 643, 'London'),  
(5, 'Alan', 'Male', '29-JUL-1993', 500, 'London'), 
(8, 'Mice', 'Male', '16-AUG-1974', 543, 'Liverpool'),
(10, 'Elis', 'Female', '28-OCT-1990', 400, 'Leeds');

----index
----cluster index
----cluster index before deleting default index

SELECT * FROM student123siva
 
----index
----cluster index
----cluster index after deleting default index


 CREATE CLUSTERED INDEX IX_tblStudent_Gender_Score
ON student123siva(gender ASC, total_score DESC)
SELECT * FROM student123siva

CREATE CLUSTERED INDEX IX_tblStudent123siva_City_Score
ON student123siva(city ASC, total_score DESC)
SELECT * FROM student123siva

CREATE CLUSTERED INDEX IX_tblStudent123siva_Score_City
ON student123siva(total_score DESC,city ASC)
SELECT * FROM student123siva

----index
----non clustered index

CREATE NONCLUSTERED INDEX IX_tblStudent_Name
ON student123siva(name ASC)
----we cant view non cluster index
select * from IX_tblStudent_Name
