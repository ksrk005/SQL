CREATE TABLE ttt
(
Country varchar(10),
[State] varchar(10),
City varchar(10),
[population in million] int
)
INSERT INTO ttt VALUES('India', 'Delhi','East Delhi',9 )
 
INSERT INTO ttt VALUES('India', 'Delhi','South Delhi',8 )
 
INSERT INTO ttt VALUES('India', 'Delhi','North Delhi',5.5)
 
INSERT INTO ttt VALUES('India', 'Delhi','West Delhi',7.5)
 
INSERT INTO ttt VALUES('India', 'Karnataka','Bangalore',9.5)
 
INSERT INTO ttt VALUES('India', 'Karnataka','Belur',2.5)
 
INSERT INTO ttt VALUES('India', 'Karnataka','Manipal',1.5)
 
INSERT INTO ttt VALUES('India', 'Maharastra','Mumbai',30)
 
INSERT INTO ttt VALUES('India', 'Maharastra','Pune',20)
 
INSERT INTO ttt VALUES('India', 'Maharastra','Nagpur',11 )
 
INSERT INTO ttt VALUES('India', 'Maharastra','Nashik',6.5)

select * from ttt
-- sum is aggreagate func--
select sum([population in million]) as [total population] from ttt 
select max([population in million]) as [max population] from ttt 
select min([population in million]) as [min population] from ttt 
select avg([population in million]) as [avg population] from ttt 
select count([population in million]) as [count population] from ttt 


select state, sum ([population in million]) as ght
from ttt group by state
having sum ([population in million]) >50

select * from ttt where city in('pune','mumbai')
select city from ttt where [population in million]=(select min([population in million]) as [min population] from ttt) 