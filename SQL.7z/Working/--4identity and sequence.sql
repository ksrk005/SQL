--identity


create table tbl1_ksrk005
(
	[student id] int identity (101,1) not null,
	[first naem] nvarchar(200) not null,
	[last name] nvarchar(200) null,
	[email] nvarchar (100) null
);
insert into tbl1_ksrk005 values('siva','k','ksrk005')
insert into tbl1_ksrk005 values('siva2','k2','2ksrk005')
insert into tbl1_ksrk005 values('siva3','k3','3ksrk005')
insert into tbl1_ksrk005 values('siva4','k4','4ksrk005')
insert into tbl1_ksrk005 values('siva5','k5','5ksrk005')


select * from tbl1_ksrk005


delete from tbl1_ksrk005 where [student id]=101


insert into tbl1_ksrk005 values('siva6','k6','4ksrk005')
insert into tbl1_ksrk005 values('siva7','k7','5ksrk005')


delete from tbl_ksrk005 where [student id]=104


insert into tbl_ksrk005 values('siva8','k8','8ksrk005')
insert into tbl_ksrk005 values('siva9','k9','9ksrk005')



--sequence


create table tbl2_ksrk005
(
	create sequence [student id] int
	START WITH 6000
	INCREMENT BY 2
	MINVALUE  4000
	MAXVALUE  6005
	CYCLE 
	[first name] nvarchar(200) not null,
	[last name] nvarchar(200) null,
	[email] nvarchar (100) null
);
insert into tbl2_ksrk005 values('siva1','k1','ksrk005')
insert into tbl2_ksrk005 values('siva2','k2','2ksrk005')
insert into tbl2_ksrk005 values('siva3','k3','3ksrk005')
insert into tbl2_ksrk005 values('siva4','k4','4ksrk005')
insert into tbl2_ksrk005 values('siva5','k5','5ksrk005')


select * from tbl2_ksrk005


delete from tbl2_ksrk005 where [student id]=101


insert into tbl2_ksrk005 values('siva6','k6','6ksrk005')
insert into tbl2_ksrk005 values('siva7','k7','7ksrk005')


delete from tbl2_ksrk005 where [student id]=104


insert into tbl2_ksrk005 values('siva8','k8','8ksrk005')
insert into tbl2_ksrk005 values('siva9','k9','9ksrk005')
