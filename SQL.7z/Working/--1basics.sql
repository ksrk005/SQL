/*create table*/
CREATE TABLE tblEmployee_siva (
    E_ID int primary key,
	E_First_Name varchar(23),
	E_Last_Name varchar(23),
);

/*insert into table two types*/
/*type 1*/
insert into tblEmployee_siva
values(1,'z','a')
insert into tblEmployee_siva
values(2,'y','b')
insert into tblEmployee_siva
values(3,'x','c')
insert into tblEmployee_siva
values(4,'w','d')
/*type 2*/
insert into tblEmployee_siva(E_ID,E_First_Name) 
values (5,'v')

/*display fully*/
select * from tblEmployee_siva

/*display full row from selected column*/
select E_First_Name,E_Last_Name from tblEmployee_siva

/*display full column from selected row*/
select * from tblEmployee_siva where E_id=2
select * from tblEmployee_siva where E_ID>4
select * from tblEmployee_siva where E_First_Name='z'

/*display full column from selected row with or condition*/
select * from tblEmployee_siva where E_First_Name='z' or E_Last_Name='a'

/*display full column from selected row with and condition*/
insert into tblEmployee_siva
values(6,'z','aa')
select * from tblEmployee_siva where E_First_Name='z'
select * from tblEmployee_siva where E_First_Name='z' and E_Last_Name='a'
select * from tblEmployee_siva where E_First_Name='z' and E_Last_Name='c'

/*display full column from selected row with starting with or ending with condition*/
insert into tblEmployee_siva
values(7,'siva','k')
insert into tblEmployee_siva
values(8,'sivarama','k')
insert into tblEmployee_siva
values(9,'sivaramakrishnan','k')
select * from tblEmployee_siva where E_First_Name like 's%'
select * from tblEmployee_siva where E_First_Name like 's__a'
select * from tblEmployee_siva where E_First_Name like 's%a'
select * from tblEmployee_siva where E_First_Name like '%a'
select * from tblEmployee_siva where E_First_Name like 's%n'
select * from tblEmployee_siva where E_Last_Name like '%k' 


/*delete-just table content, drop-table itself, truncate-also table log*/
delete from tblEmployee_siva
drop table tblEmployee_siva
truncate table tblEmployee_siva

/*alter table*/
alter table tblEmployee_siva
drop column Genders
select * from tblEmployee_siva


update tblEmployee_siva
set E_Last_Name='sds'
where E_Last_Name is null

--default means further values are default--
alter table tblEmployee_siva
add address varchar(25)default 'chennai'
insert into tblEmployee_siva(E_id,E_First_Name,E_Last_Name)
values(10,'sivaramakrishnan_route','k')

